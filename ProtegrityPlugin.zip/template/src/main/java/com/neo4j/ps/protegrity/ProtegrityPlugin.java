package com.neo4j.ps.protegrity;

import java.util.*;
import java.util.stream.*;


import org.neo4j.graphdb.*;
import org.neo4j.procedure.*;

import com.protegrity.ap.java.*;

import org.neo4j.logging.*;



public class ProtegrityPlugin
{


        @UserFunction("Protegrity.protectData")
        @Description("protectData - this function calls Protegrity to protect data according to the specified protection data element by name")
        public String protectData(
                        // @Name("UserName") String _username,
                        @Name("DataElement") String _dataElement,
                        @Name("DataValue") String _dataValue,
                        @Name(value = "doDebug", defaultValue = "false") Boolean doDebug
                        ) 
	{
		// initialize variables for Protegrity
		String[] inputStringArray = new String[1];
        String[] ProtectStringArray = new String[1];
		String protectedString = null;

	
		// instantiate call to protegrity protector
        Protector protector = null;
		try {
			protector = Protector.getProtector();
			//if (doDebug) log.info("Protegrity Protector Instantiated");
		}
		catch (Exception e) {
			//log.info("Couldn't create instantiate Protegrity Protector: %s",e);
			System.out.println("Couldn't create instantiate Protegrity Protector: " + e);
		}

		// create a protegrity session
        SessionObject session = null;
		try {
			// get a protegrity session...hard coding the username to "neo4j" since that is the OS username
            // that the database (and protegrity application protector elements) is running under
            session = protector.createSession("neo4jprd");
			//if (doDebug) log.info("Protegrity session created");
		}
		catch (Exception e) {
			//log.info("Couldn't create create session with Protegrity: %s",e);
			System.out.println("Couldn't create instantiate Protegrity Protector: " + e);
        }


		// call Protegrity to encrypt/protect data
                inputStringArray[0] = _dataValue;
		try {
			if(!protector.protect(session,_dataElement,inputStringArray,ProtectStringArray))
				//log.info("Call to Protegrity protect API failed for element '%s'!!! \nError :%s",_dataElement,protector.getLastError(session));
				System.out.println("Call to Protegrity protect API failed for element");
			protectedString = ProtectStringArray[0];
			//if (doDebug) log.info("Call to Protegrity protect API succeeded for element '%s' --> protected value: '%s'!!!",_dataElement,protectedString);
		}
        catch (Exception e) {
                //log.info("Couldn't invoke data proection using element '%s' -> error: %s",_dataElement,e);
        		System.out.println("Couldn't create instantiate Protegrity Protector: " + e);
        }

		return protectedString;
	}





        @SuppressWarnings("deprecation")
		@UserFunction("Protegrity.unprotectData")
        @Description("unprotectData - this function calls Protegrity to unprotect data according to the specified protection data element by name")
        public String unprotectData(
                        // @Name("UserName") String _username,
                        @Name("DataElement") String _dataElement,
                        @Name("ProtectedValue") String _protectedValue,
                        @Name(value = "doDebug", defaultValue = "false") Boolean doDebug
                        )
        {
                // initialize variables for Protegrity
                String[] inputStringArray = new String[1];
                String[] UnProtectStringArray = new String[1];
                String unprotectedString = null;

                // instantiate call to protegrity protector
                Protector protector = null;
                try {
                        protector = Protector.getProtector();
                        //if (doDebug) log.info("Protegrity Protector Instantiated");
                }
                catch (Exception e) {
                        //log.info("Couldn't create instantiate Protegrity Protector: %s",e);
                		System.out.println("Couldn't create instantiate Protegrity Protector: " + e);
                }

                // create a protegrity session
                SessionObject session = null;
                try {
                        // get a protegrity session...hard coding the username to "neo4j" since that is the OS username
                        // that the database (and protegrity application protector elements) is running under
                        session = protector.createSession("neo4jprd");
                       
                        //if (doDebug) log.info("Protegrity session created");
                }
                catch (Exception e) {
                        //log.info("Couldn't create create session with Protegrity: %s",e);
                		System.out.println("Couldn't create instantiate Protegrity Protector: " + e);
                }


                // call Protegrity to encrypt/protect data
                inputStringArray[0] = _protectedValue;
                try {
                        if(!protector.unprotect(session,_dataElement,inputStringArray,UnProtectStringArray))
                                //log.info("Call to Protegrity protect API failed for element '%s' and value '%s'!!! \nError :%s",_dataElement,inputStringArray[0],protector.getLastError(session));
                        	System.out.println("Call to Protegrity protect API failed for element");
                        unprotectedString = UnProtectStringArray[0];
                        //if (doDebug) log.info("Call to Protegrity protect API succeeded for element '%s' !!!",_dataElement);
                }
                catch (Exception e) {
                        //log.info("Couldn't invoke data proection using element '%s' and value '%s' -> error: %s",_dataElement,inputStringArray[0],e);
                		System.out.println("Couldn't create instantiate Protegrity Protector: " + e);
                } finally {
                	session = null;
                	protector = null;
                }

                return unprotectedString;
        }


//			if(!protector.reprotect(session,DE,DE,ProtectStringArray,ReProtectStringArray))
//				System.out.println("reprotect api failed !!! \nError :"+protector.getLastError(session));
//			else
//				System.out.println( "4.) ReProtect Output: " + ReProtectStringArray[0] );

}
